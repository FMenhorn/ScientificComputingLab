Authors: Erik Wannerberg, Friedrich Menhorn

Instructions:
The worksheet 2 solution is present in the MATLAB script file 'worksheet2.m'. The other files are function files used in the script and/or solutions to subtasks in the worksheet. Descriptions, explanations and comments are to be found in each file respectively.

